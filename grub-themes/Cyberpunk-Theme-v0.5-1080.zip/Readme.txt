Install 

sudo ./install.sh

Best Viewed on 1920x1080
